Studio Yebisu Mem0 diagram example. Silent portrait/landscape film and editable sources. Serve over HTTP. Original API input/output preserved; no model weights or private database included.
