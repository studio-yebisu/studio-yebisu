Studio Yebisu silent concept diagram. No spoken guides or audio tracks. Serve over HTTP and read the example README and video/README. Original upstream inputs/outputs preserved.
