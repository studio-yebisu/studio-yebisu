Studio Yebisu: examples/humanizer-example/README.md を参照。一式のルートからHTTP配信してください。入力は架空。認証・モデル履歴・依存本体は含みません。
