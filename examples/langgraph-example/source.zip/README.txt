Studio Yebisu: examples/langgraph-example/README.md を参照。展開先ルートからHTTP配信し /examples/langgraph-example/ を開けます。実行結果の保存viewerで、入力と単価は架空です。
