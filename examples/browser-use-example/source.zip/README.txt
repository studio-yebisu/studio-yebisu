Studio Yebisu: examples/browser-use-example/README.mdを参照。展開先をHTTP配信してください。架空の検索入力と実Browser Use操作結果、編集できる無音動画を含みます。
