Studio Yebisu：examples/design-taste-example/README.md を参照。展開先をHTTP配信すると、実作例と26秒の無音動画を確認できます。
