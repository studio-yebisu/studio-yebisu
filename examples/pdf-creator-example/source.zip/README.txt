Studio Yebisu：examples/pdf-creator-example/README.md を参照。一式のルートをHTTP配信すると実PDFとページ画像・動画を確認できます。依存とフォントの本体は含みません。
