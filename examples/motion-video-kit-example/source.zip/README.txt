Studio Yebisu の編集ソースです。examples/motion-video-kit-example/README.md を開いてください。展開したフォルダをHTTP配信すると作例と動画を確認できます。共通カタログの画面はオンライン版を使い、ZIPには含めていません。
