# Ryoshu紹介ページと映像ソース

このZIPはRyoshuアプリ本体ではなく、公開用の紹介ページ、編集可能な映像ソース、架空の保存済み4例、MP4です。

展開後、このフォルダーで `python -m http.server 8000 --bind 127.0.0.1` を実行し、http://127.0.0.1:8000/ を開きます。映像を再生成するときは examples/ryoshu-local/video/README.md を参照してください。

アプリ本体・100件の原本と結果: https://github.com/studio-yebisu/ryoshu

コードはMIT、MP4はMEDIA-LICENSE.mdのクレジット条件です。
