# Ryoshu紹介ページ・映像ソース

これはアプリ本体ではありません。展開後 `python -m http.server 8000 --bind 127.0.0.1` で起動し、http://127.0.0.1:8000/ を開きます。
アプリ本体: https://github.com/studio-yebisu/ryoshu
映像の再生成: examples/ryoshu-local/video/README.md
コードはMIT、MP4はMEDIA-LICENSE.mdに従います。
