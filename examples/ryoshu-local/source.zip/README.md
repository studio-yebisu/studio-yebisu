Ryoshu introduction sources. Preserve the examples/ and media/ directory layout.
Open examples/ryoshu-local/index.html through a local HTTP server.
Film and4 saved examples are v0.4; app-update.json records v1 separately.
Code MIT; MP4 credit terms in MEDIA-LICENSE.md.
