Studio Yebisu: examples/train-llm-from-scratch-example/README.mdを参照。独自の英文入力、実CPU学習の出力、再現コード、無音動画と編集ソースを含みます。モデル重みは含みません。展開先をHTTP配信してください。
