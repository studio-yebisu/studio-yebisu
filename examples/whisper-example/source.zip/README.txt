Studio Yebisu: examples/whisper-example/README.mdを参照。展開先ルートをHTTP配信し /examples/whisper-example/ を開きます。実ASRの保存済み出力を編集する作例です。
