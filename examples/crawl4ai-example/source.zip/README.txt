Studio Yebisu: examples/crawl4ai-example/README.mdを参照。展開先ルートでHTTP配信し、/examples/crawl4ai-example/を開きます。保存結果のビューアで、入力は架空のローカル文書です。
