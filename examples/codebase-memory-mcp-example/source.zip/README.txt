Studio Yebisu: examples/codebase-memory-mcp-example/README.mdを参照。展開先ルートでHTTP配信し、/examples/codebase-memory-mcp-example/を開きます。保存結果のビューアで、コード・注文・金額は架空です。
