Studio Yebisu: examples/knowledge-work-plugins-example/README.mdを参照。展開先ルートをHTTP配信します。架空のメモへスキルを実適用した保存済み出力を閲覧します。
