Studio Yebisu: examples/learn-harness-engineering-example/README.mdを参照。架空のメモ入力、実NodeCLIの出力、検証前後の引き継ぎファイル、無音動画と編集ソースを含みます。展開先をHTTP配信してください。
