Studio Yebisu：examples/make-interfaces-feel-better-example/README.md を参照。一式のルートをHTTP配信すると画面と動画を確認できます。編集ソース・レンダラーを同梱、依存はlockfile固定で導入します。
