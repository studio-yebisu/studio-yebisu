Studio Yebisu: examples/motion-primitives-example/README.mdを参照。展開先ルートでHTTP配信し、/examples/motion-primitives-example/を開きます。架空の手順書を検索する実ブラウザー作例です。
