Studio Yebisu: examples/ragas-example/README.mdを参照。展開先をHTTP配信してください。架空の固定FAQ入力と実Ragas出力、編集できる無音動画を含みます。
