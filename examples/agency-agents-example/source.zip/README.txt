Studio Yebisu: examples/agency-agents-example/README.mdを参照。展開先ルートをHTTP配信してください。実際の入力・設計・実装・保存JSONを含む架空イベントの作例です。
