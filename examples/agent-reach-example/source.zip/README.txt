Studio Yebisu: examples/agent-reach-example/README.md を参照。一式のルートからHTTP配信してください。認証・生の投稿・モデル履歴・依存本体は含みません。
